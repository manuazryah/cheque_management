<?php

use yii\helpers\Html;
?>

<?= '<div>Plan  choosed <span style="color: green;
    text-transform: uppercase;
    font-weight: bold;">' . $model->plans->plan_name . ' </span>,Plan upgraded date  ' . $model->plan_date . ' and Plan Expired On ' . $model->plan_end_date . '</div><br>'; ?>

